This is release branch v2.1 of MathJax.
